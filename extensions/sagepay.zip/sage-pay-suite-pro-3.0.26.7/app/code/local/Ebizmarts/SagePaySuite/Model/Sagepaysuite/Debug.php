<?php

class Ebizmarts_SagePaySuite_Model_Sagepaydirectpro_Debug extends Mage_Core_Model_Abstract
{
	protected function _construct()
	{
		$this->_init('sagepaysuite2/sagepaysuite_debug');
	}
}