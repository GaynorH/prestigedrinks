<?php

/**
 * Server info block
 *
 * @category   Ebizmarts
 * @package    Ebizmarts_SagePaySuite
 * @author     Ebizmarts <info@ebizmarts.com>
 */
class Ebizmarts_SagePaySuite_Block_Info_SagePayServer extends Ebizmarts_SagePaySuite_Block_Info_Suite
{

}