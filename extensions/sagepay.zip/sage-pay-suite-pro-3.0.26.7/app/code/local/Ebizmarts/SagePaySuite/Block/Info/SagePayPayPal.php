<?php

/**
 * PayPal info block
 *
 * @category   Ebizmarts
 * @package    Ebizmarts_SagePaySuite
 * @author     Ebizmarts <info@ebizmarts.com>
 */

class Ebizmarts_SagePaySuite_Block_Info_SagePayPayPal extends Ebizmarts_SagePaySuite_Block_Info_Suite
{


}